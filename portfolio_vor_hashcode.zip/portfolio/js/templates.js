$(document).ready(function(){
    $('#img-container').click(function(){
        alert('alles wird gut');
    })
})