<?php
   // echo $_SERVER["REMOTE_ADDR"];
?>
<div class="personal">
    <h1>Personal Information</h1>
    <div class="personal_info">
        <ul>
            <li><a href="/" id="main">Shevchenko Denis</a></li>
            <li><a href="#" id="contacts">Web-developer</a></li>
            <li><a href="#" id="portfolio">25.08.1990</a></li>        
            <li><a href="#" id="portfolio">Russia</a></li>        
        </ul>
    </div>
</div>
<div class="skills" style="">
    <h1>Technical Skills</h1>
    <table class="table" width="60%" style="margin: 0 auto;">
          <thead>
            <tr>
              <th colspan="2"><h3>Programming</h3></th>
              <th colspan="1"><h3>&nbsp;</h3></th>
              <th colspan="2"><h3>Design Tools</h3></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td width="20%">PHP 5</td>
              <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 70%;"></div>
                    </div>
              </td>
              <td width="20%">&nbsp;</td>
                <td width="20%">Photoshop</td>
                <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 90%;"></div>
                    </div>
                </td>
            </tr>
            <tr>
              <td width="20%">Javascript</td>
              <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 60%;"></div>
                    </div>
              </td>
                <td width="10%">&nbsp;</td>
                <td width="20%">Corel Draw</td>
                <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 70%;"></div>
                    </div>
                </td>
            </tr>
            <tr>
              <td width="20%">CSS3</td>
              <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 80%;"></div>
                    </div>
              </td>
                <td width="10%">&nbsp;</td>
                <td width="20%">InDesign</td>
                <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 50%;"></div>
                    </div>
                </td>
            </tr>
            <tr>
              <td width="20%">HTML 5</td>
              <td width="20%">
                    <div class="progress progress-info">
                    <div class="bar" style="width: 40%;"></div>
                    </div>
              </td>
                <td width="20%">&nbsp;</td>
                <td width="20%">&nbsp;

                </td>
            </tr>
          </tbody>
    </table>
</div>